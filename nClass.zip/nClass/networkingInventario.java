package com.example.jpolanco.vistasapp.network;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.CountDownTimer;
import android.util.Log;

import com.example.jpolanco.vistasapp.dao.daoInventario;
import com.example.jpolanco.vistasapp.entidades.ctl_medicamento;
import com.example.jpolanco.vistasapp.entidades.inventario;
import com.example.jpolanco.vistasapp.entidades.tableAjusteMed;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

/**
 * Created by JPolanco on 7/22/18.
 */

public class networkingInventario extends AsyncTask<String, String,String> {

    //final static String url = "http://10.45.0.112:8080/sicia-minsal/rest/SiciaWS/SaveOperation";

    ArrayList<tableAjusteMed> ta ;
    Activity mActivity;
    ProgressDialog progDailog;
    String line;
    daoInventario daoI ;

    public networkingInventario(Activity act) {
        super();
        // do stuff
        //this.ta = param;
        this.mActivity = act;


    }

    public void alertError(String titulo, String mensaje){
        AlertDialog.Builder builder1 = new AlertDialog.Builder(this.mActivity);
        builder1.setTitle(titulo);
        builder1.setMessage(mensaje);
        builder1.setCancelable(true);

        builder1.setPositiveButton(
                "Aceptar",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                    }
                });
        AlertDialog alert11 = builder1.create();
        alert11.show();
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();

        progDailog = new ProgressDialog(this.mActivity);
        progDailog.setTitle("Actualizando inventario");
        progDailog.setMessage("El inventario esta siendo actualizado");
        //progDailog.setIndeterminate(false);
        progDailog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        //progDailog.setCancelable(true);
        progDailog.show();

    }

    @Override
    protected void onPostExecute(String s) {
        super.onPostExecute(s);
        new CountDownTimer(1000, 1000) {

            public void onTick(long millisUntilFinished) {
                // You don't need anything here
            }

            public void onFinish() {
                if(progDailog.isShowing()){
                    progDailog.dismiss();
                    progDailog.cancel();  /* important to invoke cancel() */
                }
                JSONObject jobj = null;
                String code =  null;
                String descp  = null;
                ArrayList<inventario> inventarios = new ArrayList<inventario>();
                try {
                    jobj = new JSONObject(line);
                    code = jobj.getString("code");
                    descp = jobj.getString("description");
                    if (code.equals("0")) {
                        //move to next page
                        //Toast.makeText(LoginActivity.this, msg,Toast.LENGTH_SHORT).show();
                        JSONArray arrayInventario = (JSONArray) jobj.getJSONArray("detalles");
                        for(int i = 0; i< arrayInventario.length(); i++){
                            JSONObject obj = (JSONObject) arrayInventario.get(i);
                            inventario inv = new inventario();
                            inv.id_medicamento = obj.getString("id_medicamento");
                            inv.cantidad = Integer.parseInt(obj.getString("cantidad"));
                            inv.fecha_vencimiento = obj.getString("fechaVencimiento");
                            Log.e("MED",inv.id_medicamento + Integer.toString(inv.cantidad));
                            inventarios.add(inv);
                        }
                        daoI = new daoInventario(mActivity);
                        daoI.insertInventarioFromArray(inventarios);
                        alertError(descp,"Se ha actualizado el inventario con éxito");


                    } else {
                        //Toast.makeText(LoginActivity.this, msg,Toast.LENGTH_SHORT).show();
                        alertError(code,descp);
                    }


                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }.start();


    }

    protected String doInBackground(String... urls) {
        try{
            //URL uri = new URL(url);
            URL uri = new URL(urls[0]);
            HttpURLConnection urlConnection = (HttpURLConnection) uri.openConnection();
            urlConnection.setRequestMethod("POST");
            urlConnection.setRequestProperty("Content-Type","application/json;charset=UTF-8");
            urlConnection.setRequestProperty("Accept","application/json");
            //urlConnection.setDoOutput(true);
            urlConnection.setDoInput(true);

            JSONObject codAmbulancia = new JSONObject();
            codAmbulancia.put("idAmbulancia", "A301");
            DataOutputStream os = new DataOutputStream(urlConnection.getOutputStream());
            //os.writeBytes(URLEncoder.encode(jsonParam.toString(), "UTF-8"));
            os.writeBytes(codAmbulancia.toString());
            os.flush();

            //read anwser
            BufferedReader serverAnswer = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
            line = serverAnswer.readLine();
            //<--If any response from server
            //use it as you need, if server send something back you will get it here.
            //Toast.makeText(MainActivity.,line,Toast.LENGTH_LONG).show();

            os.close();
            serverAnswer.close();
            urlConnection.disconnect();
            return line;
        }
        catch(Exception e){
            e.printStackTrace();
        }
        return null;
    }
}
