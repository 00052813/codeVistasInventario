package com.example.jpolanco.vistasapp.dao;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import com.example.jpolanco.vistasapp.ConexionSQLiteHelper;
import com.example.jpolanco.vistasapp.entidades.ctl_medicamento;
import com.example.jpolanco.vistasapp.entidades.inventario;

import java.util.ArrayList;

/**
 * Created by JPolanco on 7/10/18.
 */

public class daoInventario {

    Context contexto;
    ConexionSQLiteHelper conn ;
    SQLiteDatabase db ;

    public daoInventario(Context cont){
        this.contexto = cont;
        this.conn = new ConexionSQLiteHelper(this.contexto,"bd_sap",null,7);
        this.db = conn.getWritableDatabase();
    }

    public ArrayList<inventario> getInventario(){

        SQLiteDatabase db = conn.getReadableDatabase();
        String campos [] = {"id_medicamento","fecha_vencimiento","cantidad"};
        ArrayList<inventario> inventarios =  new ArrayList<inventario>();
        //Cursor cursorMedicamentos = db.execSQL("SELECT * FROM ctl_medicamento");
        Cursor cursorInventario = db.query("inventario",campos,null,null,null,null,null);
        while(cursorInventario.moveToNext()){
            inventario inv = new inventario();
            inv.setId_medicamento(cursorInventario.getString(0));
            inv.setFecha_vencimiento(cursorInventario.getString(1));
            inv.setCantidad(cursorInventario.getInt(2));
            inventarios.add(inv);
        }
        return inventarios;
    }

    public ArrayList<inventario> getInventarioFilter(ArrayList<String> ids){
        String []columns = {"id_medicamento","fecha_vencimiento","cantidad"};
        //String []selectionArgs = {id+"%"};
        //String []selectionArgs = {filter};
        //Cursor cursorMedicamentos = db.query(true, "ctl_medicamento", columns, "id" + " LIKE ?", new String[] {"%"+ filter+ "%" }, null, null, null, null);
        ArrayList<inventario> invList = new ArrayList<inventario>();
        Cursor cursorInventario = db.query("inventario", columns, String.format(" id_medicamento NOT IN (%s)", argsArrayToString(ids)), null, null, null, null);
        while(cursorInventario.moveToNext()){
            inventario inv = new inventario();
            inv.setId_medicamento(cursorInventario.getString(0));
            inv.setFecha_vencimiento(cursorInventario.getString(1));
            inv.setCantidad(cursorInventario.getInt(2));
            invList.add(inv);
            Log.v("INVENTARIOS",inv.getId_medicamento());
            //db.close();

        }
        return invList;

    }

    public void insertInventarioPrueba(){
        db.execSQL("DELETE FROM inventario");
        inventario inv = new inventario();
        inv.setId_medicamento("00905005");
        //inv.setFecha_vencimiento();
        inv.setCantidad(20);
        inventario inv2 = new inventario();
        inv2.setId_medicamento("02304015");
        //inv.setFecha_vencimiento();
        inv2.setCantidad(10);
        ArrayList<inventario> arrayInv = new ArrayList<inventario>();
        arrayInv.add(inv);
        arrayInv.add(inv2);

        ContentValues cv = new ContentValues(); //Declare once
        for(int i=0;i<arrayInv.size();i++){
            cv.put("id_medicamento", arrayInv.get(i).getId_medicamento());
            cv.put("cantidad",arrayInv.get(i).getCantidad());
            cv.put("fecha_vencimiento", "19/91/21");
            db.insert("inventario", null, cv); //Insert each time for loop count
        }
        //db.close();

    }


    String argsArrayToString(ArrayList<String> args) {
        StringBuilder argsBuilder = new StringBuilder();
        //argsBuilder.append("\"");
        argsBuilder.append("'");
        final int argsCount = args.size();
        for (int i=0; i<argsCount; i++) {
            argsBuilder.append(args.get(i));
            argsBuilder.append("'");
            if (i < argsCount - 1) {
                argsBuilder.append(",");
                argsBuilder.append("'");
            }
        }
        //argsBuilder.append("'");
        Log.v("INVFILTER",argsBuilder.toString());
        return argsBuilder.toString();
    }

    public void insertInventarioFromArray(ArrayList<inventario> inventarios){
        db.execSQL("DELETE FROM inventario");
        ContentValues cv = new ContentValues(); //Declare once
        for(int i=0;i<inventarios.size();i++){
            cv.put("id_medicamento", inventarios.get(i).getId_medicamento());
            cv.put("cantidad",inventarios.get(i).getCantidad());
            cv.put("fecha_vencimiento", inventarios.get(i).getFecha_vencimiento());
            db.insert("inventario", null, cv); //Insert each time for loop count
        }
        //db.close();
    }
    /*
    String argsArrayToString(ArrayList<String> args) {
        String[] mStringArray = new String[args.size()];
        mStringArray = args.toArray(mStringArray);
        String inClause = mStringArray.toString();
        inClause = inClause.replace("[","(");
        inClause = inClause.replace("]",")");
        Log.v("INVFILTER",inClause);
        return inClause;
    }
    */
}
