package com.example.jpolanco.vistasapp.entidades;

/**
 * Created by JPolanco on 6/24/18.
 */

public class Operacion {
    private Integer id_operacion;
    private Integer id_ambulancia;
    private Integer id_producto;
    private Integer cantidad;
    //no se usa

    public void setId_operacion(Integer id_operacion) {
        this.id_operacion = id_operacion;
    }

    public void setId_ambulancia(Integer id_ambulancia) {
        this.id_ambulancia = id_ambulancia;
    }

    public void setId_producto(Integer id_producto) {
        this.id_producto = id_producto;
    }

    public void setCantidad(Integer cantidad) {
        this.cantidad = cantidad;
    }

    public Integer getId_operacion() {
        return id_operacion;
    }

    public Integer getId_ambulancia() {
        return id_ambulancia;
    }

    public Integer getId_producto() {
        return id_producto;
    }

    public Integer getCantidad() {
        return cantidad;
    }
}
