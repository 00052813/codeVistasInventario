package com.example.jpolanco.vistasapp.clasesAux;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.TextView;

import com.example.jpolanco.vistasapp.R;
import com.example.jpolanco.vistasapp.entidades.tableAjusteMed;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by JPolanco on 7/13/18.
 */

public class tableAjusteMedAdapter extends ArrayAdapter<tableAjusteMed> {
    private static final String TAG = "AdapterTable";
    private Context mContext;
    int mResource;
    ArrayList<tableAjusteMed> TA;

    public tableAjusteMedAdapter(@NonNull Context context,int mResource, @NonNull ArrayList<tableAjusteMed> objects) {
        super(context, mResource, objects);
        this.TA = objects;
        //this.mContext = context;
        //mResource = resource;
        //table adapter para la vista previa de operacion de ajuste inventario
    }



    @NonNull
    @Override
    public View getView(final int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        //for(int i= 0; i< TA.size(); i++){
        tableAjusteMed rowAjusteMed = TA.get(position);
        String ds_medicamento = rowAjusteMed.getDs_ds_medicamento();
        String ajuste = rowAjusteMed.getAjuste();
        String nuevaC = rowAjusteMed.getNuevaCant();

        //tableAjusteMed ajusteT = new tableAjusteMed();
        //ajusteT.setDs_ds_medicamento(ds_medicamento);
        //ajusteT.setAjuste(ajuste);
        //ajusteT.setNuevaCant(nuevaC);
        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.table_ajuste, parent, false);
        }

        TextView tvMed = (TextView) convertView.findViewById(R.id.medNomT);
        TextView tvCant = (TextView) convertView.findViewById(R.id.nuevaCT);
        TextView tvAjuste = (TextView) convertView.findViewById(R.id.ajustarT);
        Button btnAjuste = (Button) convertView.findViewById(R.id.btnElim);
        //TA.get(position).setBtnEliminar(btnAjuste);

        btnAjuste.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                /*
                int which = -1;
                Object obj = v.getTag();
                if (obj instanceof Integer)
                {
                    which = (Integer) obj;
                }

                Log.e("POSISITON", which+"");
                selected.put(which, "TEST");
                notifyDataSetChanged();
                */
                Log.e("CLICKBTN",TA.get(position).getAjuste());
                TA.remove(position);
                notifyDataSetChanged();
            }});
        /*
        for(int i = 0; i< ajusteTable.size(); i++){
            Log.v("vistasAPP", ajusteTable.get(i).getDs_ds_medicamento());
        }
         */
        //Log.v("adapter", Integer.toString(position) );
        tvMed.setText(ds_medicamento);
        tvCant.setText(nuevaC);
        tvAjuste.setText(ajuste);

        return convertView;
        ////llena el tabla adapter para mostrarlo en la vista
    }
}


