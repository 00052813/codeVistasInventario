package com.example.jpolanco.vistasapp.dao;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import com.example.jpolanco.vistasapp.ConexionSQLiteHelper;
import com.example.jpolanco.vistasapp.R;
import com.example.jpolanco.vistasapp.entidades.ctl_medicamento;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.*;
import java.util.ArrayList;

/**
 * Created by JPolanco on 7/8/18.
 */

public class daoMedicamentos {
    Context contexto;
    ConexionSQLiteHelper conn ;
    SQLiteDatabase db ;
    JSONArray JSONMed;

    public daoMedicamentos(Context cont){
        this.contexto = cont;
        this.conn = new ConexionSQLiteHelper(this.contexto,"bd_sap",null,7);
        this.db = conn.getWritableDatabase();
        //DAO de medicamentos
    }

    public ArrayList<ctl_medicamento> getMedicamentosById(String [] arrayId){

        ArrayList<ctl_medicamento> arrayMed = new ArrayList<ctl_medicamento>();
        for(int i = 0; i< arrayId.length; i++){
            ctl_medicamento med = new ctl_medicamento();
            med = getMedicamentoById(arrayId[i]);
            arrayMed.add(med);
        }
        return arrayMed;
        //no se usa
    }

    public ctl_medicamento getMedicamentoById(String filter){
        String []columns = {"ds_medicamento","ds_presentacion","ds_fechaVencimiento", "id"};
        //String []selectionArgs = {id+"%"};
        String []selectionArgs = {filter};
        Cursor cursorMedicamentos = db.query(true, "ctl_medicamento", columns, "id" + " LIKE ?", new String[] {"%"+ filter+ "%" }, null, null, null, null);
        if(cursorMedicamentos.moveToNext()){
            ctl_medicamento medicamento = new ctl_medicamento();
            medicamento.setDs_medicamento(cursorMedicamentos.getString(0));
            medicamento.setDs_presentacion(cursorMedicamentos.getString(1));
            medicamento.setDs_fechaVencimiento(cursorMedicamentos.getString(2));
            medicamento.setId(cursorMedicamentos.getString(3));
            //db.close();

            return medicamento;
        }
        else {
            Log.v("vistasAPP", "nell papu");
            return null;
        }
        //obtiene un objeto medicamento decacuerdo al ID que se le envia
    }

    public ArrayList<ctl_medicamento> insertMedicamentos(){
        db.execSQL("DELETE FROM ctl_medicamento");
        ctl_medicamento m1 = new ctl_medicamento("00905005", "Acido acitalesico", null, null, null, "mg", null,"2019-01-19");
        ctl_medicamento m2 = new ctl_medicamento("02304015", "Dexametasona fostato", null, null, null, "mg", null,"2018-01-19");
        ctl_medicamento m3 = new ctl_medicamento("02000015", "Clorferamina natorato", null, null, null, "ML", null,"2018-01-19");
        ArrayList<ctl_medicamento> medicamentos = new ArrayList<>();
        medicamentos.add(m1);
        medicamentos.add(m2);
        medicamentos.add(m3);
        ContentValues cv = new ContentValues(); //Declare once
        for(int i=0;i<medicamentos.size();i++){
            cv.put("id", medicamentos.get(i).getId());
            cv.put("ds_medicamento",medicamentos.get(i).getDs_medicamento());
            cv.put("ds_presentacion",medicamentos.get(i).getDs_presentacion());
            cv.put("ds_fechaVencimiento", medicamentos.get(i).getDs_fechaVencimiento());
            db.insert("ctl_medicamento", null, cv); //Insert each time for loop count
        }
        //db.close();
        return medicamentos;
        //no se usa
    }



    public ArrayList<ctl_medicamento>  getMedicamentos(){
        SQLiteDatabase db = conn.getReadableDatabase();
        String campos [] = {"ds_medicamento","ds_presentacion","ds_fechaVencimiento"};
        ArrayList<ctl_medicamento> medsList =  new ArrayList<ctl_medicamento>();
        //Cursor cursorMedicamentos = db.execSQL("SELECT * FROM ctl_medicamento");
        Cursor cursorMedicamentos = db.query("ctl_medicamento",campos,null,null,null,null,null);
        while(cursorMedicamentos.moveToNext()){
            ctl_medicamento medicamento = new ctl_medicamento();
            medicamento.setDs_medicamento(cursorMedicamentos.getString(0));
            medicamento.setDs_presentacion(cursorMedicamentos.getString(1));
            medicamento.setDs_fechaVencimiento(cursorMedicamentos.getString(2));
            medsList.add(medicamento);
        }
        return medsList;
        // no se usa
    }

    public void JSONFromFiles(Context m) throws IOException, JSONException {
        InputStream is = m.getResources().openRawResource(R.raw.med);
        Writer writer = new StringWriter();
        char[] buffer = new char[1024];
        try {
            Reader reader = new BufferedReader(new InputStreamReader(is, "UTF-8"));
            int n;
            while ((n = reader.read(buffer)) != -1) {
                writer.write(buffer, 0, n);
            }
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            is.close();
        }

        String jsonString = writer.toString();
        JSONMed =  new JSONArray(jsonString);
        //Lee un archivo TXT tipo JSOn y lo transforma a un objeto JSON
    }

    public void insertMedicamentosJSONFILE() throws JSONException {
        db.execSQL("DELETE FROM ctl_medicamento");
        ArrayList<ctl_medicamento> medicamentos = new ArrayList<>();
        try {
            // iterate over the rules
            for (int i=0; i<JSONMed.length();i++){
                JSONObject obj = (JSONObject) JSONMed.get(i);
                ctl_medicamento med = new ctl_medicamento();
                med.id = obj.getString("nm_codigo_sinab");
                med.ds_medicamento = obj.getString("ds_medicamento");
                med.ds_presentacion = obj.getString("ds_concentracion");
                medicamentos.add(med);
            }
        } catch (JSONException e){
            e.printStackTrace();
        }
        ContentValues cv = new ContentValues(); //Declare once
        for(int i=0;i<medicamentos.size();i++){
            cv.put("id", medicamentos.get(i).getId());
            cv.put("ds_medicamento",medicamentos.get(i).getDs_medicamento());
            cv.put("ds_presentacion",medicamentos.get(i).getDs_presentacion());
            cv.put("ds_fechaVencimiento", "");
            db.insert("ctl_medicamento", null, cv); //Insert each time for loop count
        }
        //db.close();
        //return medicamentos;

        //ingresa los medicamentos en la tabla segun el archivo RAW de minsal (que se convirtio en JSON en el metodo antertior)
    }
}
