package com.example.jpolanco.vistasapp.entidades;

/**
 * Created by JPolanco on 7/8/18.
 */

public class inventario {
    private String id_medicamento;
    private Integer cantidad;
    private String fecha_vencimiento;

    public void setId_medicamento(String id_medicamrento) {
        this.id_medicamento = id_medicamrento;
    }

    public void setCantidad(Integer cantidad) {
        this.cantidad = cantidad;
    }

    public void setFecha_vencimiento(String fecha_vencimiento) {
        this.fecha_vencimiento = fecha_vencimiento;
    }

    public String getId_medicamento() {
        return id_medicamento;
    }

    public Integer getCantidad() {
        return cantidad;
    }

    public String getFecha_vencimiento() {
        return fecha_vencimiento;
    }
}
