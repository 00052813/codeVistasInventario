package com.example.jpolanco.vistasapp;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.example.jpolanco.vistasapp.utilities.utilities;

/**
 * Created by JPolanco on 6/20/18.
 */

public class ConexionSQLiteHelper extends SQLiteOpenHelper{


    public ConexionSQLiteHelper(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(utilities.crear_table_ctl_medicamento);
        db.execSQL(utilities.crear_table_inventario);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int va, int vn) {
        db.execSQL("DROP TABLE IF EXISTS ctl_medicamento");
        db.execSQL("DROP TABLE IF EXISTS inventario");
        db.execSQL(utilities.crear_table_ctl_medicamento);
        db.execSQL(utilities.crear_table_inventario);
    }

    /**
     * Created by JPolanco on 6/24/18.
     */
}
