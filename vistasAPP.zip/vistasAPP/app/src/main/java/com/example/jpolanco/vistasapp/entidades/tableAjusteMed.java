package com.example.jpolanco.vistasapp.entidades;

import android.widget.Button;
import android.widget.TextView;

/**
 * Created by JPolanco on 7/13/18.
 */

public class tableAjusteMed {
    private String id_medicamento;
    private String ds_ds_medicamento;
    private  String ajuste;
    private String nuevaCant;
    //private Button btnEliminar;

    public void setId_medicamento(String id_medicamento) {
        this.id_medicamento = id_medicamento;
    }

    public void setDs_ds_medicamento(String ds_ds_medicamento) {
        this.ds_ds_medicamento = ds_ds_medicamento;
    }


    public void setAjuste(String ajuste) {
        this.ajuste = ajuste;
    }

    public void setNuevaCant(String nuevaCant) {
        this.nuevaCant = nuevaCant;
    }

    public String getId_medicamento() {
        return id_medicamento;
    }

    public String getDs_ds_medicamento() {
        return ds_ds_medicamento;
    }

    public String getAjuste() {
        return ajuste;
    }

    public String getNuevaCant() {
        return nuevaCant;
    }
}
