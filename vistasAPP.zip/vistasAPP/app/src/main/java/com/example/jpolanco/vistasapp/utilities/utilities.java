package com.example.jpolanco.vistasapp.utilities;

/**
 * Created by JPolanco on 7/3/18.
 */

public  class utilities {
    public static final  String crear_table_ctl_medicamento = "CREATE TABLE ctl_medicamento\n" +
            "(\n" +
            "    id TEXT,\n" +
            "    ds_medicamento TEXT,\n" +
            "    nm_codigo_sinab TEXT,\n" +
            "    ds_concentracion TEXT,\n" +
            "    ds_forma_farmaceutica TEXT,\n" +
            "    ds_presentacion TEXT,\n" +
            "    ds_dosificacion TEXT,\n" +
            "    ds_fechaVencimiento TEXT\n" +
            ");";
    public static final  String crear_table_inventario = "CREATE TABLE inventario\n" +
            "(\n" +
            "    id_medicamento TEXT,\n" +
            "    cantidad INTEGER,\n" +
            "    fecha_vencimiento TEXT\n" +
            ");";
}
