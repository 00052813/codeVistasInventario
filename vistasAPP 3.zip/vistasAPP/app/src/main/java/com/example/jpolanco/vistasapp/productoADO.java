package com.example.jpolanco.vistasapp;

import android.support.v7.app.AppCompatActivity;

/**
 * Created by JPolanco on 6/24/18.
 */

public class productoADO extends AppCompatActivity {

// no se ocupa
}
