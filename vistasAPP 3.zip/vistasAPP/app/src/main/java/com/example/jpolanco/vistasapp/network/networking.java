package com.example.jpolanco.vistasapp.network;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.CountDownTimer;
import android.util.Log;
import android.widget.Toast;

import com.example.jpolanco.vistasapp.ajusteInventario;

import com.example.jpolanco.vistasapp.clasesAux.delayedProgressDialog;
import com.example.jpolanco.vistasapp.entidades.tableAjusteMed;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

/**
 * Created by JPolanco on 6/26/18.
 */

public class networking extends AsyncTask<String, String,String> {
    //final static String url = "http://10.45.0.112:8080/sicia-minsal/rest/SiciaWS/SaveOperation";

    ArrayList<tableAjusteMed> ta ;
    Activity mActivity;
    ProgressDialog progDailog;
    String line;

    public networking(ArrayList<tableAjusteMed> param, Activity act) {
        super();
        // do stuff
        this.ta = param;
        this.mActivity = act;
        //esta clase se usa para enviar datos a Wservice de ajusteInventario y salida_inven

    }

    public void alertError(String titulo, String mensaje){
        AlertDialog.Builder builder1 = new AlertDialog.Builder(this.mActivity);
        builder1.setTitle(titulo);
        builder1.setMessage(mensaje);
        builder1.setCancelable(true);

        builder1.setPositiveButton(
                "Aceptar",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                    }
                });
        AlertDialog alert11 = builder1.create();
        alert11.show();
        //muestra un mensaje deseado exitoso
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();

        progDailog = new ProgressDialog(this.mActivity);
        progDailog.setTitle("Actualizando inventario");
        progDailog.setMessage("El inventario esta siendo actualizado");
        //progDailog.setIndeterminate(false);
        progDailog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        //progDailog.setCancelable(true);
        progDailog.show();

        //crea una barra de progreso para verificar el estado de la operacion enviada al WService

    }

    @Override
    protected void onPostExecute(String s) {
        super.onPostExecute(s);
        new CountDownTimer(1000, 1000) {

            public void onTick(long millisUntilFinished) {
                // You don't need anything here
            }

            public void onFinish() {
                if(progDailog.isShowing()){
                    progDailog.dismiss();
                    progDailog.cancel();  /* important to invoke cancel() */
                }
                JSONObject jobj = null;
                String code =  null;
                String descp  = null;
                try {
                    jobj = new JSONObject(line);
                    code = jobj.getString("code");
                    descp = jobj.getString("description");
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                if (code.equals("0")) {
                    //move to next page
                    //Toast.makeText(LoginActivity.this, msg,Toast.LENGTH_SHORT).show();
                    alertError(descp,"Se ha actualizado el inventario con éxito");


                } else {
                    //Toast.makeText(LoginActivity.this, msg,Toast.LENGTH_SHORT).show();
                    alertError(code,descp);
                }
            }
        }.start();

        //Si la operacion se ha realizado con exito, actualiara la vista
        //si hubo un error de conexion, se cancelara la accion y mostrara un mensaje de error
    }

    protected String doInBackground(String... urls) {
        try{
            //URL uri = new URL(url);
            URL uri = new URL(urls[0]);
            HttpURLConnection urlConnection = (HttpURLConnection) uri.openConnection();
            urlConnection.setRequestMethod("POST");
            urlConnection.setRequestProperty("Content-Type","application/json;charset=UTF-8");
            urlConnection.setRequestProperty("Accept","application/json");
            //urlConnection.setDoOutput(true);
            urlConnection.setDoInput(true);
            JSONArray operaciones = new JSONArray();
            for (int i=0;i<ta.size(); i++){
                JSONObject operacionesDetail = new JSONObject();
                operacionesDetail.put("idProducto",ta.get(i).getId_medicamento());
                operacionesDetail.put("cantidad",Integer.parseInt(ta.get(i).getAjuste()));
                operacionesDetail.put("fechaVencProducto","2019-10-10");
                operacionesDetail.put("tipoOperacion","S");
                operacionesDetail.put("justificacion" , "Ingreso de nuevo medicamento");
                operaciones.put(operacionesDetail);

            }




            JSONObject operation = new JSONObject();
            operation.put("idAmbulancia", 1);
            operation.put("idInventario", 1);
            operation.put("operaciones",operaciones);
            Log.i("JSON",operation.toString());
            DataOutputStream os = new DataOutputStream(urlConnection.getOutputStream());
            //os.writeBytes(URLEncoder.encode(jsonParam.toString(), "UTF-8"));
            os.writeBytes(operation.toString());

            os.flush();

            //read anwser
            BufferedReader serverAnswer = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
            line = serverAnswer.readLine();

             //<--If any response from server
            //use it as you need, if server send something back you will get it here.
            //Toast.makeText(MainActivity.,line,Toast.LENGTH_LONG).show();
            JSONObject jobj = new JSONObject(line);
            String code = jobj.getString("code");
            String descp = jobj.getString("description");

            if (code.equals("0")) {
                //move to next page
                //Toast.makeText(LoginActivity.this, msg,Toast.LENGTH_SHORT).show();
                System.out.println("Description: " + descp);

            } else {
                //Toast.makeText(LoginActivity.this, msg,Toast.LENGTH_SHORT).show();
                System.out.println("Error: " + descp);

            }
            os.close();
            serverAnswer.close();
            urlConnection.disconnect();
            return line; //verificar cuando hay error (0)
        }
        catch(Exception e){
            e.printStackTrace();
        }
        return null;
        //esto envia los datos desde la vista donde se mando a llamar el WService hacia el Wservice
        //en line obtiene el JSON enviado desde el WService
    }
}
