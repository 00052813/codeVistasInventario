package com.example.jpolanco.vistasapp.clasesAux;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.Handler;


/**
 * Created by JPolanco on 7/17/18.
 */

public class delayedProgressDialog extends ProgressDialog {
    private static Handler dialogHandler;
    private Runnable runner;

    static {
        dialogHandler = new Handler();
    }

    public delayedProgressDialog(Context context) {
        super(context);
    }

    public static ProgressDialog show (Context c, CharSequence title, CharSequence msg, long afterDelayMilliSec)
    {
        final delayedProgressDialog pd = new delayedProgressDialog(c);
        pd.setTitle(title);
        pd.setMessage(msg);
        pd.setCancelable(true);
        pd.runner = new Runnable() {

            public void run() {
                try {
                    pd.show();
                }
                catch (Exception e) {
                    /* do nothing */
                }
            }
        };
        dialogHandler.postDelayed(pd.runner, afterDelayMilliSec);
        return pd;
    }

    @Override
    public void cancel() {
        dialogHandler.removeCallbacks(runner);
        super.cancel();
    }

}
