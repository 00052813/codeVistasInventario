package com.example.jpolanco.vistasapp.entidades;

/**
 * Created by JPolanco on 7/3/18.
 */

public class ctl_medicamento {
    public String id;
    public String ds_medicamento;
    public String nm_codigo_sinab;
    public Integer ds_concentracion;
    public String ds_forma_farmaceutica;
    public String ds_presentacion;
    public String ds_dosificacion;
    public String ds_fechaVencimiento;

    public ctl_medicamento(){

    }

    public ctl_medicamento(String id, String ds_medicamento, String nm_codigo_sinab, Integer ds_concentracion, String ds_forma_farmaceutica, String ds_presentacion, String ds_dosificacion, String ds_fechaVencimiento) {
        this.id = id;
        this.ds_medicamento = ds_medicamento;
        this.nm_codigo_sinab = nm_codigo_sinab;
        this.ds_concentracion = ds_concentracion;
        this.ds_forma_farmaceutica = ds_forma_farmaceutica;
        this.ds_presentacion = ds_presentacion;
        this.ds_dosificacion = ds_dosificacion;
        this.ds_fechaVencimiento = ds_fechaVencimiento;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getDs_medicamento() {
        return ds_medicamento;
    }

    public void setDs_medicamento(String ds_medicamento) {
        this.ds_medicamento = ds_medicamento;
    }

    public String getNm_codigo_sinab() {
        return nm_codigo_sinab;
    }

    public void setNm_codigo_sinab(String nm_codigo_sinab) {
        this.nm_codigo_sinab = nm_codigo_sinab;
    }

    public Integer getDs_concentracion() {
        return ds_concentracion;
    }

    public void setDs_concentracion(Integer ds_concentracion) {
        this.ds_concentracion = ds_concentracion;
    }

    public String getDs_forma_farmaceutica() {
        return ds_forma_farmaceutica;
    }

    public void setDs_forma_farmaceutica(String ds_forma_farmaceutica) {
        this.ds_forma_farmaceutica = ds_forma_farmaceutica;
    }

    public String getDs_presentacion() {
        return ds_presentacion;
    }

    public void setDs_presentacion(String ds_presentacion) {
        this.ds_presentacion = ds_presentacion;
    }

    public String getDs_dosificacion() {
        return ds_dosificacion;
    }

    public void setDs_dosificacion(String ds_dosificacion) {
        this.ds_dosificacion = ds_dosificacion;
    }

    public String getDs_fechaVencimiento() {
        return ds_fechaVencimiento;
    }

    public void setDs_fechaVencimiento(String ds_fechaVencimiento) {
        this.ds_fechaVencimiento = ds_fechaVencimiento;
    }
}
