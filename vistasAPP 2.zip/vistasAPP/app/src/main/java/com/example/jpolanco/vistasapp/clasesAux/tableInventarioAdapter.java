package com.example.jpolanco.vistasapp.clasesAux;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import com.example.jpolanco.vistasapp.R;
import com.example.jpolanco.vistasapp.dao.daoMedicamentos;
import com.example.jpolanco.vistasapp.entidades.inventario;
import com.example.jpolanco.vistasapp.entidades.tableAjusteMed;

import java.util.ArrayList;

/**
 * Created by JPolanco on 7/15/18.
 */

public class tableInventarioAdapter extends ArrayAdapter<inventario> {
    private static final String TAG = "AdapterTable";
    private Context mContext;
    int mResource;
    ArrayList<inventario> TA;
    daoMedicamentos daoM ;
    ListView myView;

    public tableInventarioAdapter(@NonNull Context context, int mResource, @NonNull ArrayList<inventario> objects) {
        super(context, mResource, objects);
        this.TA = objects;
        //this.mContext = context;
        //mResource = resource;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        //for(int i= 0; i< TA.size(); i++){
        daoM = new daoMedicamentos(getContext());
        inventario rowInventario = TA.get(position);
        String ds_medicamento = daoM.getMedicamentoById(rowInventario.getId_medicamento()).getDs_medicamento();
        String fechaVenc = rowInventario.getFecha_vencimiento();
        String cant = rowInventario.getCantidad().toString();

        //tableAjusteMed ajusteT = new tableAjusteMed();
        //ajusteT.setDs_ds_medicamento(ds_medicamento);
        //ajusteT.setAjuste(ajuste);
        //ajusteT.setNuevaCant(nuevaC);
        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.inventario_partial, parent, false);
        }

        TextView tvMed = (TextView) convertView.findViewById(R.id.medNomT);
        TextView tvFV = (TextView) convertView.findViewById(R.id.fechaVenc);
        TextView tvCA = (TextView) convertView.findViewById(R.id.cantidad);
        /*
        for(int i = 0; i< ajusteTable.size(); i++){
            Log.v("vistasAPP", ajusteTable.get(i).getDs_ds_medicamento());
        }
         */
        //Log.v("adapter", Integer.toString(position) );
        tvMed.setText(ds_medicamento);
        tvFV.setText(fechaVenc);
        tvCA.setText(cant);
        return convertView;
    }
}
